.. _connect_hdfs:

Confluent HDFS Connector
========================

Contents:

.. toctree::
   :maxdepth: 3

   hdfs_connector
   configuration_options
   changelog
